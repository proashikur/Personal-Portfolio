# Personal portfolio & Blog site ([quick-preview](http://portfolio-quick-preview.html-5.me/)) 

This is my attempt to create fully responsive personal portfolio & blog for practicing front-end/back-end while learning Laravel framework.

## Include

* [Composer](https://getcomposer.org/) to install Laravel and dependencies
* [Laravel Framework v5.2](https://laravel.com/docs/5.2) for you know...
* [Bootstrap v3.3.6](http://getbootstrap.com) for CSS and jQuery plugins
* [Font Awesome](http://fortawesome.github.io/Font-Awesome) for the awesome icons
* [Stroke-gap-icons](http://graphicburger.com/stroke-gap-icons-webfont/) for mouse-icon in main section